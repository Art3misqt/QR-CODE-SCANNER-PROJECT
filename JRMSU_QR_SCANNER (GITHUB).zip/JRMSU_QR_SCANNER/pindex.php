<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code Reader</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        body {
            background-image: url('background-image.jpg');
            background-size: cover;
            min-height: 100vh;
            display: flex;
            align-items: center;
            padding: 20px 0;
        }
        
        .container {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            padding: 30px;
            max-width: 900px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #3498db;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .header p {
            color: #7f8c8d;
            font-size: 16px;
        }
        
        .scanner-container {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        #preview {
            width: 100%;
            height: 300px;
            object-fit: cover;
            display: block;
        }
        
        .scanner-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }
        
        .scan-line {
            position: absolute;
            height: 2px;
            width: 100%;
            background: #3498db;
            top: 30%;
            animation: scan 2s linear infinite;
            box-shadow: 0 0 10px rgba(52, 152, 219, 0.5);
        }
        
        @keyframes scan {
            0% { top: 30%; }
            50% { top: 70%; }
            100% { top: 30%; }
        }
        
        .scanner-corner {
            position: absolute;
            width: 30px;
            height: 30px;
            border-color: #3498db;
            border-style: solid;
        }
        
        .corner-tl {
            top: 0;
            left: 0;
            border-width: 5px 0 0 5px;
        }
        
        .corner-tr {
            top: 0;
            right: 0;
            border-width: 5px 5px 0 0;
        }
        
        .corner-bl {
            bottom: 0;
            left: 0;
            border-width: 0 0 5px 5px;
        }
        
        .corner-br {
            bottom: 0;
            right: 0;
            border-width: 0 5px 5px 0;
        }
        
        .form-container {
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
        }
        
        .camera-select {
            margin-bottom: 15px;
        }
        
        .status {
            padding: 10px;
            border-radius: 5px;
            margin-top: 15px;
            display: none;
        }
        
        .status.scanning {
            display: block;
            background-color: #d1ecf1;
            color: #0c5460;
        }
        
        .status.success {
            display: block;
            background-color: #d4edda;
            color: #155724;
        }
        
        .status.error {
            display: block;
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .btn-scan {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 50px;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-scan:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .instructions {
            background-color: #e8f4fc;
            border-left: 4px solid #3498db;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
        }
        
        .instructions h5 {
            color: #3498db;
            margin-bottom: 10px;
        }
        
        .instructions ol {
            padding-left: 20px;
            margin-bottom: 0;
        }
        
        .instructions li {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-qrcode me-2"></i>QR Code Scanner</h1>
            <p>Position a QR code in front of your camera to scan</p>
        </div>
        
        <div class="row">
            <!-- Scanner section -->
            <div class="col-md-6 mb-4 mb-md-0">
                <div class="scanner-container">
                    <video id="preview"></video>
                    <div class="scanner-overlay">
                        <div class="scanner-corner corner-tl"></div>
                        <div class="scanner-corner corner-tr"></div>
                        <div class="scanner-corner corner-bl"></div>
                        <div class="scanner-corner corner-br"></div>
                        <div class="scan-line"></div>
                    </div>
                </div>
                
                <div class="camera-select mt-3">
                    <label for="camera-select" class="form-label">Select Camera:</label>
                    <select class="form-select" id="camera-select">
                        <option value="">Loading cameras...</option>
                    </select>
                </div>
                
                <div class="status scanning" id="status-scanning">
                    <i class="fas fa-sync-alt fa-spin me-2"></i> Scanning for QR codes...
                </div>
                <div class="status success" id="status-success">
                    <i class="fas fa-check-circle me-2"></i> QR code scanned successfully!
                </div>
                <div class="status error" id="status-error">
                    <i class="fas fa-exclamation-circle me-2"></i> <span id="error-message"></span>
                </div>
            </div>
            
            <!-- Result section -->
            <div class="col-md-6">
                <div class="form-container">
                    <form action="insert1.php" method="post" class="form-horizontal">
                        <div class="mb-3">
                            <label for="text" class="form-label">Scanned QR Code Content:</label>
                            <input type="text" name="text" id="text" readonly class="form-control" placeholder="Scan a QR code to see content here">
                        </div>
                        
                        <button type="submit" class="btn btn-scan w-100">
                            <i class="fas fa-paper-plane me-2"></i> Submit Scanned Code
                        </button>
                    </form>
                    
                    <!-- Display success/error message if present -->
                    <?php if (isset($_GET['msg'])): ?>
                        <div class="alert alert-info mt-3">
                            <i class="fas fa-info-circle me-2"></i> <?php echo htmlspecialchars($_GET['msg']); ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="instructions">
                    <h5>How to use:</h5>
                    <ol>
                        <li>Allow camera access when prompted</li>
                        <li>Position the QR code in front of your camera</li>
                        <li>The code will be automatically scanned</li>
                        <li>Click "Submit Scanned Code" to process</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>

    <!-- Required JS libraries -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/webrtc-adapter/3.3.3/adapter.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/vue/2.1.10/vue.min.js"></script>
    <script type="text/javascript" src="https://rawgit.com/schmich/instascan-builds/master/instascan.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let scanner = new Instascan.Scanner({ 
                video: document.getElementById('preview'),
                mirror: false,
                backgroundScan: false
            });
            
            const statusScanning = document.getElementById('status-scanning');
            const statusSuccess = document.getElementById('status-success');
            const statusError = document.getElementById('status-error');
            const errorMessage = document.getElementById('error-message');
            const cameraSelect = document.getElementById('camera-select');
            
            // Function to show status
            function showStatus(element) {
                // Hide all status elements first
                statusScanning.style.display = 'none';
                statusSuccess.style.display = 'none';
                statusError.style.display = 'none';
                
                // Show the requested one
                element.style.display = 'block';
            }
            
            // Listen for scan event
            scanner.addListener('scan', function(content) {
                document.getElementById('text').value = content;
                showStatus(statusSuccess);
                
                // Auto-hide success message after 3 seconds
                setTimeout(() => {
                    if (statusSuccess.style.display === 'block') {
                        showStatus(statusScanning);
                    }
                }, 3000);
            });
            
            // Get available cameras and populate select
            Instascan.Camera.getCameras()
                .then(function(cameras) {
                    cameraSelect.innerHTML = ''; // Clear the loading message
                    
                    if (cameras.length > 0) {
                        cameras.forEach((camera, index) => {
                            const option = document.createElement('option');
                            option.value = camera.id;
                            option.text = camera.name || `Camera ${index + 1}`;
                            cameraSelect.appendChild(option);
                        });
                        
                        // Start with the back camera by default if available
                        const backCamera = cameras.find(camera => camera.name.toLowerCase().includes('back'));
                        const cameraToUse = backCamera || cameras[0];
                        scanner.start(cameraToUse);
                        cameraSelect.value = cameraToUse.id;
                        
                        showStatus(statusScanning);
                    } else {
                        errorMessage.textContent = 'No cameras found on your device.';
                        showStatus(statusError);
                    }
                })
                .catch(function(e) {
                    console.error('Camera error:', e);
                    errorMessage.textContent = 'Error accessing camera: ' + e;
                    showStatus(statusError);
                });
            
            // Handle camera selection change
            cameraSelect.addEventListener('change', () => {
                if (cameraSelect.value) {
                    const selectedCamera = Instascan.Camera.getCameras().then(cameras => {
                        return cameras.find(camera => camera.id === cameraSelect.value);
                    });
                    
                    scanner.start(selectedCamera);
                    showStatus(statusScanning);
                }
            });
        });
    </script>
</body>
</html>