<?php
// XAMPP default MySQL connection settings
$server = "localhost"; // XAMPP MySQL server
$username = "root";    // Default XAMPP username
$password = "";        // Default XAMPP password (empty)
$dbname = "qrcodereader_db"; // Your database name

// Create connection
$conn = new mysqli($server, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'text' is posted
if (isset($_POST['text'])) {
    $text = $_POST['text'];

    // Insert scanned QR code value as STUDENTNAME only
    $sql = "INSERT INTO student_information (STUDENTNAME) VALUES ('$text')";

    if ($conn->query($sql) === TRUE) {
        $msg = "New record created successfully";
    } else {
        $msg = "Error: " . $conn->error;
    }

    $conn->close();

    // Redirect back to index.php with message
    header("Location: pindex.php?msg=" . urlencode($msg));
    exit();
}
?>