<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root"; // Replace with your MySQL username
$password = ""; // Replace with your MySQL password
$dbname = "facial_recognition_db";   // Replace with your database name

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}

// Get the captured face descriptor and image from the request
$face_image = isset($_POST['face_image']) ? $_POST['face_image'] : null;
$face_descriptor_json = isset($_POST['face_descriptor']) ? $_POST['face_descriptor'] : null;

if (!$face_image || !$face_descriptor_json) {
    echo json_encode(['success' => false, 'error' => 'Missing face image or descriptor']);
    exit();
}

// Decode the captured face descriptor
$captured_descriptor = json_decode($face_descriptor_json, true);
if (!$captured_descriptor || count($captured_descriptor) !== 128) {
    echo json_encode(['success' => false, 'error' => 'Invalid captured descriptor']);
    exit();
}

// Function to calculate Euclidean distance between two descriptors
function calculateEuclideanDistance($desc1, $desc2) {
    if (count($desc1) !== count($desc2)) {
        return PHP_FLOAT_MAX;
    }
    $sum = 0;
    for ($i = 0; $i < count($desc1); $i++) {
        $diff = $desc1[$i] - $desc2[$i];
        $sum += $diff * $diff;
    }
    return sqrt($sum);
}

// Fetch all students' descriptors and photo data from the database
try {
    $stmt = $conn->prepare("SELECT student_id, first_name, last_name, program, year_level, photo_data, face_descriptor, created_at FROM students");
    $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $best_match = null;
    $best_distance = PHP_FLOAT_MAX;
    $threshold = 0.8; // Increased threshold for testing

    foreach ($students as $student) {
        $stored_descriptor = json_decode($student['face_descriptor'], true);
        if (!$stored_descriptor || count($stored_descriptor) !== 128) {
            file_put_contents('debug.log', "Invalid descriptor for student_id: " . $student['student_id'] . "\n", FILE_APPEND);
            continue;
        }
        $distance = calculateEuclideanDistance($captured_descriptor, $stored_descriptor);
        file_put_contents('debug.log', "Distance for student_id " . $student['student_id'] . ": " . $distance . "\n", FILE_APPEND);
        if ($distance < $best_distance) {
            $best_distance = $distance;
            $best_match = $student;
        }
    }

    if ($best_match && $best_distance <= $threshold) {
        $photo_base64 = $best_match['photo_data']; // Use base64 directly

        echo json_encode([
            'success' => true,
            'name' => $best_match['first_name'] . ' ' . $best_match['last_name'],
            'student_id' => $best_match['student_id'],
            'course' => $best_match['program'],
            'year_level' => $best_match['year_level'],
            'status' => 'Active',
            'last_login' => $best_match['created_at'],
            'face_image' => $photo_base64
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Student not found in database. Best distance: ' . $best_distance]);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}

register_shutdown_function(function() {
    if (connection_aborted() || connection_status() != CONNECTION_NORMAL) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Server error or connection aborted.']);
    }
});

$conn = null;
?>